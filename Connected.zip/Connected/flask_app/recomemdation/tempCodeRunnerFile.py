import json 
# from werkzeug import Response

# with open('custome.json', 'w', encoding='utf-8') as f:
#     data = json.load(f)
#     data = Response.json()
